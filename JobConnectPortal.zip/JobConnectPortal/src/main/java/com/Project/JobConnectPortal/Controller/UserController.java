package com.Project.JobConnectPortal.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Project.JobConnectPortal.Model.LoginRequest;
import com.Project.JobConnectPortal.Model.Users;
import com.Project.JobConnectPortal.Service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userservice;  

    @PostMapping("/register")
    // Original code - commented out
    // public ResponseEntity<String> register(@RequestBody Users user) {
    //     try {
    //         userservice.registerUser(user);  
    //         return new ResponseEntity<>("Registration successful", HttpStatus.OK);
    //     } catch (Exception e) {
    //         return new ResponseEntity<>("Error: " + e.getMessage(), HttpStatus.BAD_REQUEST);
    //     }
    // }
    
    // Fixed code - returns JSON response instead of plain string
    public ResponseEntity<Map<String, String>> register(@RequestBody Users user) {
        Map<String, String> response = new HashMap<>();
        try {
            userservice.registerUser(user);  
            response.put("message", "Registration successful");
            return new ResponseEntity<>(response, HttpStatus.OK);
        } catch (Exception e) {
            response.put("message", "Error: " + e.getMessage());
            return new ResponseEntity<>(response, HttpStatus.BAD_REQUEST);
        }
    }
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> login(@RequestBody LoginRequest loginRequest) {
        // Call the service to validate the user
        String result = userservice.login(loginRequest.getEmail(), loginRequest.getPassword(), loginRequest.getType());

        // Prepare the response
        Map<String, String> response = new HashMap<>();
        response.put("message", result);  

        // Return the response as a JSON object
        return ResponseEntity.ok(response);
    }
}
