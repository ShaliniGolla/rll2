package com.Project.JobConnectPortal.Service;

import com.Project.JobConnectPortal.DAO.EmployerDAO;
import com.Project.JobConnectPortal.Model.JobPostings;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Collections;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;

public class EmployerServiceTest {

    @Mock
    private EmployerDAO employerDAO;

    @InjectMocks
    private EmployerService employerService;

    public EmployerServiceTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetAllJobs() {
        JobPostings job = new JobPostings();
        when(employerDAO.getAllJobs()).thenReturn(Collections.singletonList(job));

        List<JobPostings> jobs = employerService.getAllJobs();
        assertThat(jobs).hasSize(1);
        verify(employerDAO, times(1)).getAllJobs();
    }

    @Test
    public void testAddJob() {
        JobPostings job = new JobPostings();
        when(employerDAO.addJob(job)).thenReturn("Job added successfully!");

        String result = employerService.addJob(job);
        assertThat(result).isEqualTo("Job added successfully!");
        verify(employerDAO, times(1)).addJob(job);
    }
} 