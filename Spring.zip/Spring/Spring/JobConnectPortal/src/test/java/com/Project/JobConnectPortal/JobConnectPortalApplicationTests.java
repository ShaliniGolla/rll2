package com.Project.JobConnectPortal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobConnectPortalApplicationTests {

	@Test
	void contextLoads() {
	}

}
