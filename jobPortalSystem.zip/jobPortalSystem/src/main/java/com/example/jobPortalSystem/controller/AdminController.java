package com.example.jobPortalSystem.controller;



import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.jobPortalSystem.model.Employer;
import com.example.jobPortalSystem.model.Job;
import com.example.jobPortalSystem.model.JobSeeker;
import com.example.jobPortalSystem.service.AdminService;

//@RestController
//@RequestMapping("/api/admin")
//public class AdminController {
//
//    @Autowired
//    private AdminService adminService;
//
//    @GetMapping("/users")
//    public ResponseEntity<List<JobSeeker>> getAllJobSeekers() {
//        return ResponseEntity.ok(adminService.getAllJobSeekers());
//    }
//
//    @GetMapping("/employers")
//    public ResponseEntity<List<Employer>> getAllEmployers() {
//        return ResponseEntity.ok(adminService.getAllEmployers());
//    }
//
//    @PutMapping("/approve-user/{id}")
//    public ResponseEntity<String> approveUser(@PathVariable Long id) {
//        return ResponseEntity.ok(adminService.approveUser(id));
//    }
//
//    @GetMapping("/jobs")
//    public ResponseEntity<List<Job>> getAllJobs() {
//        return ResponseEntity.ok(adminService.getAllJobs());
//    }
//
//    @GetMapping("/report")
//    public ResponseEntity<String> generateReport() {
//        return ResponseEntity.ok(adminService.generateReport());
//    }
//}


@RestController
@RequestMapping("/api/admin")
public class AdminController {
    @Autowired 
    private AdminService adminService;
    @GetMapping("/jobseekers")
    public List<JobSeeker> getAllJobSeekers() {
        return adminService.getAllJobSeekers();
    }
    @GetMapping("/employers")
    public List<Employer> getAllEmployers() {
        return adminService.getAllEmployers();
    }
    @PutMapping("/approve/jobseeker/{id}")
    public JobSeeker approveJobSeeker(@PathVariable Long id) {
        return adminService.approveJobSeeker(id);
    }
    @PutMapping("/approve/employer/{id}")
    public Employer approveEmployer(@PathVariable Long id) {
        return adminService.approveEmployer(id);
    }
    @PutMapping("/deactivate/{type}/{id}")
    public void deactivateUser(@PathVariable String type, @PathVariable Long id) {
        adminService.deactivateUser(id, type);
    }
    @GetMapping("/jobs/pending")
    public List<Job> getPendingJobs() {
        return adminService.getPendingJobs();
    }
    @PutMapping("/approve/job/{id}")
    public Job approveJob(@PathVariable Long id) {
        return adminService.approveJob(id);
    }
    @GetMapping("/report")
    public Map<String, Object> getReport() {
        return adminService.generateReport();
    }}
 

