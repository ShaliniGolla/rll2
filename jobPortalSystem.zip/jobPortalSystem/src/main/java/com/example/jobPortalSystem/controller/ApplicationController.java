package com.example.jobPortalSystem.controller;


import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.jobPortalSystem.model.Application;
import com.example.jobPortalSystem.service.ApplicationService;
 
//@RestController
//@RequestMapping("/api/applications")
//public class ApplicationController {
// 
//    @Autowired
//    private ApplicationService applicationService;
// 
//    // ✅ Apply to a job
//    @PostMapping
//    public ResponseEntity<Application> applyToJob(@RequestBody Application application) {
//        Application saved = applicationService.apply(application);
//        return new ResponseEntity<>(saved, HttpStatus.CREATED);
//    }
// 
//    // ✅ Get all applications by job seeker ID
//    @GetMapping("/jobseeker/{jobSeekerId}")
//    public ResponseEntity<List<Application>> getApplicationsByJobSeeker(@PathVariable Long jobSeekerId) {
//        List<Application> applications = applicationService.getApplicationsByJobSeeker(jobSeekerId);
//        return new ResponseEntity<>(applications, HttpStatus.OK);
//    }
// 
//    // ✅ Update application status and send email notification
//    @PutMapping("/{applicationId}/status")
//    public ResponseEntity<Application> updateApplicationStatus(
//            @PathVariable Long applicationId,
//            @RequestParam String status,
//            @RequestParam(required = false) String feedback) {
// 
//        Application updated = applicationService.updateStatus(applicationId, status, feedback);
//        return new ResponseEntity<>(updated, HttpStatus.OK);
//    }
//}
// 




@RestController @RequestMapping("/api/applications") public class ApplicationController {

    @Autowired
    private ApplicationService applicationService;

    // ✅ Job Seeker applies to a job
    @PostMapping("/apply")
    public ResponseEntity<Application> applyToJob(
            @RequestParam Long jobId,
            @RequestParam Long seekerId
    ) {
        Application application = applicationService.apply(jobId, seekerId);
        return ResponseEntity.ok(application);
    }

    // ✅ View all applications submitted by a job seeker
    @GetMapping("/seeker/{seekerId}")
    public ResponseEntity<List<Application>> getApplicationsBySeeker(@PathVariable Long seekerId) {
        List<Application> applications = applicationService.getApplications(seekerId);
        return ResponseEntity.ok(applications);
    }

    // ✅ Employer updates application status (e.g., Shortlisted, Rejected)
    @PutMapping("/{appId}/status")
    public ResponseEntity<Application> updateApplicationStatus(
            @PathVariable 
            Long appId,
            @RequestParam 
            String status,
            @RequestParam(required = false) 
            String feedback,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate interviewDate) {
        Application updated = applicationService.updateStatus(appId, status, feedback, interviewDate);
        return ResponseEntity.ok(updated);
    }}