package com.example.jobPortalSystem.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.jobPortalSystem.model.Application;
import com.example.jobPortalSystem.model.Employer;
import com.example.jobPortalSystem.model.Job;
import com.example.jobPortalSystem.service.EmployerService;

//@RestController
//@RequestMapping("/api/employer")
//public class EmployerController {
//
//    @Autowired 
//    private EmployerService service;
//
//    @PostMapping("/jobs")
//    public ResponseEntity<Job> postJob(@RequestBody Job job) {
//        return new ResponseEntity<>(service.postJob(job), HttpStatus.CREATED);
//    }
//
//    @PutMapping("/jobs/{id}")
//    public ResponseEntity<Job> updateJob(@PathVariable Long id, @RequestBody Job job) {
//        return new ResponseEntity<>(service.updateJob(id, job), HttpStatus.OK);
//    }
//
//    @DeleteMapping("/jobs/{id}")
//    public ResponseEntity<Void> deleteJob(@PathVariable Long id) {
//        service.deleteJob(id);
//        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
//    }
//
//    @GetMapping("/jobs/{jobId}/applications")
//    public ResponseEntity<List<Application>> getApplications(@PathVariable Long jobId) {
//        return new ResponseEntity<>(service.getApplicationsForJob(jobId), HttpStatus.OK);
//    }
//
//    @GetMapping("/jobs/{jobId}/filter")
//    public ResponseEntity<List<JobSeeker>> filterCandidates(
//        @PathVariable Long jobId,
//        @RequestParam String qualification,
//        @RequestParam String experienceLevel) {
//        return new ResponseEntity<>(service.filterCandidates(jobId, qualification, experienceLevel), HttpStatus.OK);
//    }
//}
//

@RestController
@RequestMapping("/api/employers") 
public class EmployerController {

    @Autowired private EmployerService service;
    @PostMapping("/register")
    public ResponseEntity<Employer> register(@RequestBody Employer employer) {
        return new ResponseEntity<>(service.register(employer), HttpStatus.CREATED);
    }

    @PostMapping("/{id}/jobs")
    public ResponseEntity<Job> postJob(@PathVariable Long id, @RequestBody Job job) {
        return new ResponseEntity<>(service.postJob(id, job), HttpStatus.CREATED);
    }

    @PutMapping("/jobs/{jobId}")
    public ResponseEntity<Job> updateJob(@PathVariable Long jobId, @RequestBody Job job) {
        return new ResponseEntity<>(service.updateJob(jobId, job), HttpStatus.OK);
    }

    @DeleteMapping("/jobs/{jobId}")
    public ResponseEntity<Void> deleteJob(@PathVariable Long jobId) {
        service.deleteJob(jobId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/{id}/jobs")
    public List<Job> getJobs(@PathVariable Long id) {
        return service.getJobs(id);
    }

    @GetMapping("/jobs/{jobId}/applications")
    public List<Application> getApplications(@PathVariable Long jobId) {
        return service.getApplications(jobId);
    }

    @PutMapping("/applications/{appId}/status")
    public ResponseEntity<Application> updateStatus(
        @PathVariable Long appId,
        @RequestParam String status,
        @RequestParam(required = false) 
        String feedback,
        @RequestParam(required = false) 
        @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate interviewDate) {

        return new ResponseEntity<>(service.updateApplicationStatus(appId, status, feedback, interviewDate), HttpStatus.OK);
    }}
