//package com.example.jobPortalSystem.controller;
//
//
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.example.jobPortalSystem.model.Job;
//import com.example.jobPortalSystem.model.JobSeeker;
//import com.example.jobPortalSystem.service.JobSeekerService;
//
//
//@RestController
//@RequestMapping("/api/jobseekers")
//public class JobSeekerController {
//
//    @Autowired
//    private JobSeekerService jobSeekerService;
//
//    @PostMapping("/register")
//    public ResponseEntity<JobSeeker> register(@RequestBody JobSeeker jobSeeker) {
//        return ResponseEntity.ok(jobSeekerService.createJobSeeker(jobSeeker));
//    }
//
//    @GetMapping("/jobs")
//    public ResponseEntity<List<Job>> searchJobs(@RequestParam(required = false) String keyword) {
//        return ResponseEntity.ok(jobSeekerService.searchJobs(keyword));
//    }
//
//    @PostMapping("/apply/{jobId}")
//    public ResponseEntity<String> applyToJob(@PathVariable Long jobId, @RequestParam Long jobSeekerId) {
//        return ResponseEntity.ok(jobSeekerService.applyToJob(jobId, jobSeekerId));
//    }
//
//    @GetMapping("/applications/{jobSeekerId}")
//    public ResponseEntity<List<String>> trackApplications(@PathVariable Long jobSeekerId) {
//        return ResponseEntity.ok(jobSeekerService.trackApplications(jobSeekerId));
//    }
//}
//




 
package com.example.jobPortalSystem.controller;
 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
import com.example.jobPortalSystem.model.JobSeeker;
import com.example.jobPortalSystem.service.JobSeekerService;
 
@RestController
@RequestMapping("/api/jobseekers")
public class JobSeekerController {
 
    @Autowired
    private JobSeekerService jobSeekerService;
 
    // ✅ CREATE
    @PostMapping
    public ResponseEntity<JobSeeker> createJobSeeker(@RequestBody JobSeeker jobSeeker) {
        JobSeeker saved = jobSeekerService.createProfile(jobSeeker);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }
 
    // ✅ READ ALL
    @GetMapping
    public ResponseEntity<List<JobSeeker>> getAllJobSeekers() {
        return new ResponseEntity<>(jobSeekerService.getAllProfiles(), HttpStatus.OK);
    }
 
    // ✅ READ BY ID
    @GetMapping("/{id}")
    public ResponseEntity<JobSeeker> getJobSeekerById(@PathVariable Long id) {
        return jobSeekerService.getById(id)
                .map(js -> new ResponseEntity<>(js, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
 
    // ✅ UPDATE
    @PutMapping("/{id}")
    public ResponseEntity<JobSeeker> updateJobSeeker(@PathVariable Long id, @RequestBody JobSeeker updatedData) {
        return jobSeekerService.updateProfile(id, updatedData)
                .map(js -> new ResponseEntity<>(js, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
 
    // ✅ DELETE
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteJobSeeker(@PathVariable Long id) {
        if (jobSeekerService.deleteProfile(id)) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    }
}
 
 
