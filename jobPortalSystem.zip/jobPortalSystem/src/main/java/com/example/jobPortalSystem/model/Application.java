package com.example.jobPortalSystem.model;

import java.time.LocalDate;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "applications")
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String status;
    private String feedback;

    @ManyToOne
    @JoinColumn(name = "job_id")
    private Job job;

    @ManyToOne
    @JoinColumn(name = "job_seeker_id")
    private JobSeeker jobSeeker;
    
    private LocalDate appliedDate;
    private LocalDate interviewDate;

    public Application() {
    	// TODO Auto-generated constructor stub
    }
    
    
    public Application(Long id, String status, String feedback, Job job, JobSeeker jobSeeker, LocalDate appliedDate,
			LocalDate interviewDate) {
		super();
		this.id = id;
		this.status = status;
		this.feedback = feedback;
		this.job = job;
		this.jobSeeker = jobSeeker;
		this.appliedDate = appliedDate;
		this.interviewDate = interviewDate;
	}

	// Getters and Setters
    

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}

	public Job getJob() {
		return job;
	}

	public void setJob(Job job) {
		this.job = job;
	}

	public JobSeeker getJobSeeker() {
		return jobSeeker;
	}

	public void setJobSeeker(JobSeeker jobSeeker) {
		this.jobSeeker = jobSeeker;
	}
    
	
	public LocalDate getAppliedDate() {
		return appliedDate;
		}
    public void setAppliedDate(LocalDate appliedDate) {
    	this.appliedDate = appliedDate; 
    	}

    public LocalDate getInterviewDate() {
    	return interviewDate; 
    	}
    public void setInterviewDate(LocalDate interviewDate) {
    	this.interviewDate = interviewDate;
    	}
 
    
}
