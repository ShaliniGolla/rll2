package com.example.jobPortalSystem.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "jobs")
public class Job {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String description;
    private String location;
    //private String qualifications;
    private String skills;
//    private String experienceLevel;
    private String experience;

    @ManyToOne
    @JoinColumn(name = "employer_id")
    private Employer employer;
    
    private boolean approved = false;

    // Getters and Setters
    public Job() {
		// TODO Auto-generated constructor stub
	}

	public Job(Long id, String title, String description, String location, String skills,
			String experience, Employer employer) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.location = location;
		this.skills = skills;
		this.experience = experience;
		this.employer = employer;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

//	public String getQualifications() {
//		return qualifications;
//	}

//	public void setQualifications(String qualifications) {
//		this.qualifications = qualifications;
//	}
//
//	public String getExperienceLevel() {
//		return experienceLevel;
//	}
//
//	public void setExperienceLevel(String experienceLevel) {
//		this.experienceLevel = experienceLevel;
//	}

	public Employer getEmployer() {
		return employer;
	}

	public String getSkills() {
		return skills;
	}

	public void setSkills(String skills) {
		this.skills = skills;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public void setEmployer(Employer employer) {
		this.employer = employer;
	}
    
	public boolean isApproved() {
        return approved;
    }

    public void setApproved(boolean approved) {
        this.approved = approved;
    }
    
    }
