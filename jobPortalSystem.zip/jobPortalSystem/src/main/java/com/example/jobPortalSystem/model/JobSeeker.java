package com.example.jobPortalSystem.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "job_seekers")
public class JobSeeker {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String phone;
    private String education;
    private String experience;
    private String resumeUrl;

    private boolean approved = false; // ✅ Admin approval status
    private boolean active = true;

//    @OneToMany(mappedBy = "jobSeeker", cascade = CascadeType.ALL)
//    private List<Application> applications;

    // Getters and Setters
    
    public JobSeeker() {
		// TODO Auto-generated constructor stub
	}

    
    //, List<Application> applications
	public JobSeeker(Long id, String name, String email, String phone, String education, String experience,
			String resumeUrl) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phone = phone;
		this.education = education;
		this.experience = experience;
		this.resumeUrl = resumeUrl;
	
		//this.applications = applications;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setFullName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getExperience() {
		return experience;
	}

	public void setExperience(String experience) {
		this.experience = experience;
	}

	public String getResumeUrl() {
		return resumeUrl;
	}

	public void setResumeUrl(String resumeUrl) {
		this.resumeUrl = resumeUrl;
	}

	
	 public boolean isApproved() {
	        return approved;
	    }
	    public void setApproved(boolean approved) {
	        this.approved = approved;
	    }
	    public boolean isActive() {
	        return active;
	    }
	    public void setActive(boolean active) {
	        this.active = active;
	    }
	 
//	public boolean isApproved() {
//		return approved;
//	}
//
//	public void setApproved(boolean approved) {
//		this.approved = approved;
//	}

//	public List<Application> getApplications() {
//		return applications;
//	}
//
//	public void setApplications(List<Application> applications) {
//		this.applications = applications;
//	}
    
    
}
