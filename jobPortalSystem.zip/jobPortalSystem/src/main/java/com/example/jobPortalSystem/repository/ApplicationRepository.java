package com.example.jobPortalSystem.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.jobPortalSystem.model.Application;


//@Repository
//public interface ApplicationRepository extends JpaRepository<Application, Long> {
//    List<Application> findByJobId(Long jobId);
//    List<Application> findByJobSeekerId(Long jobSeekerId);
//}

@Repository 
public interface ApplicationRepository extends JpaRepository<Application, Long> {
    List<Application> findByJobSeekerId(Long jobSeekerId);
    List<Application> findByJobId(Long jobId);
    }