package com.example.jobPortalSystem.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.example.jobPortalSystem.model.Job;




@Repository
public interface JobRepository extends CrudRepository<Job, Long> {
    List<Job> findByEmployerId(Long employerId);
    List<Job> findByTitleContainingIgnoreCase(String keyword);
	List<Job> findByApprovedFalse();
}
