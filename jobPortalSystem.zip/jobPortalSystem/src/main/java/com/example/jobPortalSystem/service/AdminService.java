package com.example.jobPortalSystem.service;

import java.util.List;
import java.util.Map;

import com.example.jobPortalSystem.model.Employer;
import com.example.jobPortalSystem.model.Job;
import com.example.jobPortalSystem.model.JobSeeker;

//public interface AdminService {
//    Admin login(String username, String password);
//    List<JobSeeker> getAllJobSeekers();
//    List<Employer> getAllEmployers();
//    String approveUser(Long userId);
//    List<Job> getAllJobs();
//    String generateReport();
//}

public interface AdminService {
    List<JobSeeker> getAllJobSeekers();
    List<Employer> getAllEmployers();
    JobSeeker approveJobSeeker(Long id);
    Employer approveEmployer(Long id);
    void deactivateUser(Long id, String type); // type = "jobseeker" or "employer"List<Job> getPendingJobs();
    Job approveJob(Long jobId);

    Map<String, Object> generateReport();
	List<Job> getPendingJobs();
    
}