package com.example.jobPortalSystem.service;



import java.time.LocalDate;
import java.util.List;

import com.example.jobPortalSystem.model.Application;
 
 
//public interface ApplicationService {
// 
//    // ✅ Apply to a job
//    Application apply(Application application);
// 
//    // ✅ Get all applications by a specific job seeker
//    List<Application> getApplicationsByJobSeeker(Long jobSeekerId);
// 
//    // ✅ Update application status and feedback
//    Application updateStatus(Long applicationId, String status, String feedback);
//}

public interface ApplicationService {
    Application apply(Long jobId, Long seekerId);
    List<Application> getApplications(Long seekerId);
    Application updateStatus(Long appId, String status, String feedback, LocalDate interviewDate);
    }