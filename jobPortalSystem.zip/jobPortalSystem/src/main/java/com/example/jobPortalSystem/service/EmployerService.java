package com.example.jobPortalSystem.service;

import java.time.LocalDate;
import java.util.List;

import com.example.jobPortalSystem.model.Application;
import com.example.jobPortalSystem.model.Employer;
import com.example.jobPortalSystem.model.Job;

//public interface EmployerService {
//    Job postJob(Job job);
//    Job updateJob(Long id, Job job);
//    void deleteJob(Long id);
//    List<Application> getApplicationsForJob(Long jobId);
//    List<JobSeeker> filterCandidates(Long jobId, String qualification, String experienceLevel);
//}

public interface EmployerService {
    Employer register(Employer employer);
    List<Job> getJobs(Long employerId);
    Job postJob(Long employerId, Job job);
    Job updateJob(Long jobId, Job job);
    void deleteJob(Long jobId);
    List<Application> getApplications(Long jobId);
    Application updateApplicationStatus(Long appId, String status, String feedback, LocalDate interviewDate);
    }
