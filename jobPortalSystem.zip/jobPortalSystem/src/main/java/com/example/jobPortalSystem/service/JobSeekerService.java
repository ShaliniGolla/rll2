//package com.example.jobPortalSystem.service;
//
//import java.util.List;
//
//import com.example.jobPortalSystem.model.Job;
//import com.example.jobPortalSystem.model.JobSeeker;
//
//public interface JobSeekerService {
//    JobSeeker createJobSeeker(JobSeeker jobSeeker);
//    List<Job> searchJobs(String keyword);
//    String applyToJob(Long jobId, Long jobSeekerId);
//    List<String> trackApplications(Long jobSeekerId);
//}

package com.example.jobPortalSystem.service;

import java.util.List;
import java.util.Optional;
 
import com.example.jobPortalSystem.model.JobSeeker;
 
public interface JobSeekerService {
    JobSeeker createProfile(JobSeeker jobSeeker);
    List<JobSeeker> getAllProfiles();
    Optional<JobSeeker> getById(Long id);
    Optional<JobSeeker> updateProfile(Long id, JobSeeker updatedData);
    boolean deleteProfile(Long id);
}