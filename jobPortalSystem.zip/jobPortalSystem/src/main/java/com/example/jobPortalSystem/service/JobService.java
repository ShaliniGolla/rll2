package com.example.jobPortalSystem.service;

import java.util.List;

import com.example.jobPortalSystem.model.Job;

public interface JobService {
    Job postJob(Long employerId, Job job);
    List<Job> getJobsByEmployer(Long employerId);
    List<Job> searchJobs(String keyword);}
