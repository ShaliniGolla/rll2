package com.example.jobPortalSystem.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jobPortalSystem.model.Employer;
import com.example.jobPortalSystem.model.Job;
import com.example.jobPortalSystem.model.JobSeeker;
import com.example.jobPortalSystem.repository.EmployerRepository;
import com.example.jobPortalSystem.repository.JobRepository;
import com.example.jobPortalSystem.repository.JobSeekerRepository;
import com.example.jobPortalSystem.service.AdminService;

//@Service
//public class AdminServiceImpl implements AdminService {
//
//    @Autowired private AdminRepository adminRepo;
//    @Autowired private JobSeekerRepository seekerRepo;
//    @Autowired private EmployerRepository employerRepo;
//    @Autowired private JobRepository jobRepo;
//
//    @Override
//    public Admin login(String username, String password) {
//        return adminRepo.findByUsernameAndPassword(username, password);
//    }
//
//    @Override
//    public List<JobSeeker> getAllJobSeekers() {
//        return seekerRepo.findAll();
//    }
//
//    @Override
//    public List<Employer> getAllEmployers() {
//        return employerRepo.findAll();
//    }
//
//    @Override
//    public String approveUser(Long userId) {
//        JobSeeker seeker = seekerRepo.findById(userId).orElse(null);
//        if (seeker != null) {
//            // Assume there's a field like `approved`
////            seeker.setApproved(true);
//            seekerRepo.save(seeker);
//            return "Job seeker approved.";
//        }
//        return "User not found.";
//    }
//
//    @Override
//    public List getAllJobs() {
//        return (List) jobRepo.findAll();
//    }
//
//    @Override
//    public String generateReport() {
//        long seekers = seekerRepo.count();
//        long employers = employerRepo.count();
//        long jobs = jobRepo.count();
//        return "Report: " + seekers + " job seekers, " + employers + " employers, " + jobs + " jobs posted.";
//    }
//}

@Service public class AdminServiceImpl implements AdminService {

    @Autowired private JobSeekerRepository jobSeekerRepo;
    @Autowired private EmployerRepository employerRepo;
    @Autowired private JobRepository jobRepo;

    public List<JobSeeker> getAllJobSeekers() {
        return jobSeekerRepo.findAll();
    }

    public List<Employer> getAllEmployers() {
        return employerRepo.findAll();
    }

    public JobSeeker approveJobSeeker(Long id) {
        JobSeeker js = jobSeekerRepo.findById(id).orElseThrow();
        js.setApproved(true);
        return jobSeekerRepo.save(js);
    }

    public Employer approveEmployer(Long id) {
        Employer emp = employerRepo.findById(id).orElseThrow();
        emp.setApproved(true);
        return employerRepo.save(emp);
    }

    public void deactivateUser(Long id, String type) {
        if (type.equals("jobseeker")) {
            JobSeeker js = jobSeekerRepo.findById(id).orElseThrow();
            js.setActive(false);
            jobSeekerRepo.save(js);
        } else if (type.equals("employer")) {
            Employer emp = employerRepo.findById(id).orElseThrow();
            emp.setActive(false);
            employerRepo.save(emp);
        }
    }

    public List<Job> getPendingJobs() {
        return jobRepo.findByApprovedFalse();
    }

    public Job approveJob(Long jobId) {
        Job job = jobRepo.findById(jobId).orElseThrow();
        job.setApproved(true);
        return jobRepo.save(job);
    }

    public Map<String, Object> generateReport() {
        Map<String, Object> report = new HashMap<>();
        report.put("totalJobSeekers", jobSeekerRepo.count());
        report.put("totalEmployers", employerRepo.count());
        report.put("totalJobs", jobRepo.count());
        report.put("pendingJobs", jobRepo.findByApprovedFalse().size());
        return report;
    }}