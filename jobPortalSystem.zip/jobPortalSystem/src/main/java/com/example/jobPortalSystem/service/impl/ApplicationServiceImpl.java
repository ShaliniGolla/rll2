package com.example.jobPortalSystem.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jobPortalSystem.model.Application;
import com.example.jobPortalSystem.model.Job;
import com.example.jobPortalSystem.model.JobSeeker;
import com.example.jobPortalSystem.repository.ApplicationRepository;
import com.example.jobPortalSystem.repository.JobRepository;
import com.example.jobPortalSystem.repository.JobSeekerRepository;
import com.example.jobPortalSystem.service.ApplicationService;
 
//@Service
//public class ApplicationServiceImpl implements ApplicationService {
// 
//    @Autowired
//    private ApplicationRepository applicationRepository;
// 
//   
// 
//    @Override
//    public Application apply(Application application) {
// 
//        application.setStatus("Applied");
//        return applicationRepository.save(application);
//    }
// 
//    @Override
//    public List<Application> getApplicationsByJobSeeker(Long jobSeekerId) {
//        return applicationRepository.findByJobSeekerId(jobSeekerId);
//    }
// 
//    @Override
//    public Application updateStatus(Long applicationId, String status, String feedback) {
//        Application app = applicationRepository.findById(applicationId)
//                .orElseThrow(() -> new RuntimeException("Application not found"));
// 
//        app.setStatus(status);
//        app.setFeedback(feedback);
//        Application updated = applicationRepository.save(app);
// 
//       
//        return updated;
//    }
//}

@Service public class ApplicationServiceImpl implements ApplicationService {

    @Autowired
    private ApplicationRepository applicationRepository;

    @Autowired
    private JobRepository jobRepository;

    @Autowired
    private JobSeekerRepository jobSeekerRepository;

    @Override
    public Application apply(Long jobId, Long seekerId) {
        Job job = jobRepository.findById(jobId).orElseThrow(() -> new RuntimeException("Job not found"));
        JobSeeker seeker = jobSeekerRepository.findById(seekerId).orElseThrow(() -> new RuntimeException("Job seeker not found"));

        Application application = new Application();
        application.setJob(job);
        application.setJobSeeker(seeker);
        application.setStatus("Applied");
        application.setAppliedDate(LocalDate.now());

        return applicationRepository.save(application);
    }

    @Override
    public List<Application> getApplications(Long seekerId) {
        return applicationRepository.findByJobSeekerId(seekerId);
    }

    @Override
    public Application updateStatus(Long appId, String status, String feedback, LocalDate interviewDate) {
        Application application = applicationRepository.findById(appId).orElseThrow(() -> new RuntimeException("Application not found"));
        application.setStatus(status);
        application.setFeedback(feedback);
        application.setInterviewDate(interviewDate);
        return applicationRepository.save(application);
    }}
 
