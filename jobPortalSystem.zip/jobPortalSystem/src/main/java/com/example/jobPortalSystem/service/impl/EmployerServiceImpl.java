package com.example.jobPortalSystem.service.impl;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jobPortalSystem.model.Application;
import com.example.jobPortalSystem.model.Employer;
import com.example.jobPortalSystem.model.Job;
import com.example.jobPortalSystem.repository.ApplicationRepository;
import com.example.jobPortalSystem.repository.EmployerRepository;
import com.example.jobPortalSystem.repository.JobRepository;
import com.example.jobPortalSystem.service.EmployerService;

//@Service
//public class EmployerServiceImpl implements EmployerService {
//
//    @Autowired
//    private JobRepository jobRepo;
//
//    @Autowired
//    private ApplicationRepository appRepo;
//
//    @Autowired
//    private JobSeekerRepository seekerRepo;
//
//    @Override
//    public Job postJob(Job job) {
//        return jobRepo.save(job);
//    }
//
//    @Override
//    public Job updateJob(Long id, Job updatedJob) {
//        Job job = jobRepo.findById(id).orElseThrow();
//        job.setTitle(updatedJob.getTitle());
//        job.setDescription(updatedJob.getDescription());
//        job.setLocation(updatedJob.getLocation());
//        job.setQualifications(updatedJob.getQualifications());
//        job.setExperienceLevel(updatedJob.getExperienceLevel());
//        return jobRepo.save(job);
//    }
//
//    @Override
//    public void deleteJob(Long id) {
//        jobRepo.deleteById(id);
//    }
//
//    @Override
//    public List<Application> getApplicationsForJob(Long jobId) {
//        return appRepo.findByJobId(jobId);
//    }
//
//    @Override
//    public List<JobSeeker> filterCandidates(Long jobId, String qualification, String experienceLevel) {
//        return seekerRepo.findAll().stream()
//            .filter(js -> js.getEducation().contains(qualification) &&
//                          js.getExperience().equalsIgnoreCase(experienceLevel))
//            .collect(Collectors.toList());
//    }
//}

@Service public class EmployerServiceImpl implements EmployerService {

    @Autowired private EmployerRepository employerRepo;
    @Autowired private JobRepository jobRepo;
    @Autowired private ApplicationRepository appRepo;

    public Employer register(Employer employer) {
        return employerRepo.save(employer);
    }

    public List<Job> getJobs(Long employerId) {
        return jobRepo.findByEmployerId(employerId);
    }

    public Job postJob(Long employerId, Job job) {
        Employer emp = employerRepo.findById(employerId).orElseThrow();
        job.setEmployer(emp);
        return jobRepo.save(job);
    }

    public Job updateJob(Long jobId, Job updatedJob) {
        Job job = jobRepo.findById(jobId).orElseThrow();
        job.setTitle(updatedJob.getTitle());
        job.setDescription(updatedJob.getDescription());
        job.setLocation(updatedJob.getLocation());
        job.setSkills(updatedJob.getSkills());
        job.setExperience(updatedJob.getExperience());
        return jobRepo.save(job);
    }

    public void deleteJob(Long jobId) {
        jobRepo.deleteById(jobId);
    }

    public List<Application> getApplications(Long jobId) {
        return appRepo.findByJobId(jobId);
    }

    public Application updateApplicationStatus(Long appId, String status, String feedback, LocalDate interviewDate) {
        Application app = appRepo.findById(appId).orElseThrow();
        app.setStatus(status);
        app.setFeedback(feedback);
        return appRepo.save(app);
    }}
