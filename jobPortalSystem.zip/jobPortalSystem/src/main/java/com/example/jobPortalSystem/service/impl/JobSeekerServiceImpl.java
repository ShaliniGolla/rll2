//package com.example.jobPortalSystem.service.impl;
//
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//import java.util.stream.StreamSupport;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.example.jobPortalSystem.model.Application;
//import com.example.jobPortalSystem.model.Job;
//import com.example.jobPortalSystem.model.JobSeeker;
//import com.example.jobPortalSystem.repository.ApplicationRepository;
//import com.example.jobPortalSystem.repository.JobRepository;
//import com.example.jobPortalSystem.repository.JobSeekerRepository;
//import com.example.jobPortalSystem.service.JobSeekerService;
//
//
//
//@Service
//public class JobSeekerServiceImpl implements JobSeekerService {
//
//    @Autowired private JobSeekerRepository seekerRepo;
//    @Autowired private JobRepository jobRepo;
//    @Autowired private ApplicationRepository appRepo;
//
//    @Override
//    public JobSeeker createJobSeeker(JobSeeker jobSeeker) {
//        return seekerRepo.save(jobSeeker);
//    }
//
//    @Override
//    public List<Job> searchJobs(String keyword) {
//        if (keyword == null || keyword.isEmpty()) {
//            return StreamSupport.stream(jobRepo.findAll().spliterator(), false)
//                    .collect(Collectors.toList());
//        }
//        return jobRepo.findByTitleContainingIgnoreCase(keyword);
//    }
//
//    @Override
//    public String applyToJob(Long jobId, Long jobSeekerId) {
//        Optional<Job> job = jobRepo.findById(jobId);
//        Optional<JobSeeker> seeker = seekerRepo.findById(jobSeekerId);
//        if (job.isPresent() && seeker.isPresent()) {
//            Application app = new Application();
//            app.setJob(job.get());
//            app.setJobSeeker(seeker.get());
//            app.setStatus("Applied");
//            appRepo.save(app);
//            return "Application submitted.";
//        }
//        return "Invalid job or job seeker ID.";
//    }
//
//    @Override
//    public List<String> trackApplications(Long jobSeekerId) {
//        return appRepo.findByJobSeekerId(jobSeekerId).stream()
//            .map(app -> "Job: " + app.getJob().getTitle() + " | Status: " + app.getStatus())
//            .collect(Collectors.toList());
//    }
//}





package com.example.jobPortalSystem.service.impl;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.example.jobPortalSystem.model.JobSeeker;
import com.example.jobPortalSystem.repository.JobSeekerRepository;
import com.example.jobPortalSystem.service.JobSeekerService;
 
@Service
public class JobSeekerServiceImpl implements JobSeekerService {
 
    @Autowired
    private JobSeekerRepository repository;
 
    @Override
    public JobSeeker createProfile(JobSeeker jobSeeker) {
        return repository.save(jobSeeker);
    }
 
    @Override
    public List<JobSeeker> getAllProfiles() {
        return repository.findAll();
    }
 
    @Override
    public Optional<JobSeeker> getById(Long id) {
        return repository.findById(id);
    }
 
    @Override
    public Optional<JobSeeker> updateProfile(Long id, JobSeeker updatedData) {
        return repository.findById(id).map(existing -> {
            existing.setFullName(updatedData.getName());
            existing.setEmail(updatedData.getEmail());
            existing.setPhone(updatedData.getPhone());
            existing.setEducation(updatedData.getEducation());
            existing.setExperience(updatedData.getExperience());
            existing.setResumeUrl(updatedData.getResumeUrl());
            return repository.save(existing);
        });
    }
 
    @Override
    public boolean deleteProfile(Long id) {
        if (repository.existsById(id)) {
            repository.deleteById(id);
            return true;
        }
        return false;
    }
}
 