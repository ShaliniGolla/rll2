package com.example.jobPortalSystem.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jobPortalSystem.model.Employer;
import com.example.jobPortalSystem.model.Job;
import com.example.jobPortalSystem.repository.EmployerRepository;
import com.example.jobPortalSystem.repository.JobRepository;
import com.example.jobPortalSystem.service.JobService;

@Service public class JobServiceImpl implements JobService {

    @Autowired private JobRepository jobRepo;
    @Autowired private EmployerRepository employerRepo;

    @Override
    public Job postJob(Long employerId, Job job) {
        Employer employer = employerRepo.findById(employerId).orElseThrow();
        job.setEmployer(employer);
        return jobRepo.save(job);
    }

    @Override
    public List<Job> getJobsByEmployer(Long employerId) {
        return jobRepo.findByEmployerId(employerId);
    }

    @Override
    public List<Job> searchJobs(String keyword) {
        return jobRepo.findByTitleContainingIgnoreCase(keyword);
    }}