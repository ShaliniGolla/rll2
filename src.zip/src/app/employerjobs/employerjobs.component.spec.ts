import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployerjobsComponent } from './employerjobs.component';

describe('EmployerjobsComponent', () => {
  let component: EmployerjobsComponent;
  let fixture: ComponentFixture<EmployerjobsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [EmployerjobsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmployerjobsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
