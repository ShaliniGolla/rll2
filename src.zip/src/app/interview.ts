export interface Interview {
    interview_Id:number;
    interview_date:Date;
    application_id:number;
    userId:number;
    name:string;
    interview_status:string;
    feedback:string;
    feedbackSubmitted?: boolean; 
    }