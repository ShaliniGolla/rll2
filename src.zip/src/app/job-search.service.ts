import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, tap } from 'rxjs';
import { job } from './jobs';
// import { JobApplication } from './application';
import { Interview } from './interview';

@Injectable({
  providedIn: 'root'
})
export class JobSearchService {

  private apiUrl = 'http://localhost:8091/api/jobseeker';  
  private apiAdminUrl = 'http://localhost:8091/api/admin';
  private baseUrl = 'http://localhost:8091/api/users';  
  private apiEmployerUrl='http://localhost:8091/api/employer';
 
  private interviews: Interview[] = [];
  constructor(private http: HttpClient) {}
// Register user
  register(user: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/register`, user);
  }

  login(loginData: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/login`, loginData);
  }

  // Search jobs by job name
  searchJobsByJobName(query: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/alljobs/byName/${query}`);
  }

  // Search jobs by company name
  searchJobsByCompanyName(query: string): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/alljobs/byCompany/${query}`);
  }

  // Get all jobs (no search criteria)
  getallJobs(): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/alljobs`);
  }

  // Submit a job application
  applyForJob(applicationData: any): Observable<any> {
    console.log("Data: "+applicationData)
    return this.http.post<string>(`${this.apiUrl}/jobapply`, applicationData);
  }


//Admin
// Method to fetch job postings from the backend
getJobs(): Observable<any[]> {
  return this.http.get<any[]>(this.apiAdminUrl + "/jobpostings/all");
}

approveJob(jobId: number): Observable<any> {
  return this.http.put<any>(`${this.apiAdminUrl}/jobpostings/approve/${jobId}`, {}, { responseType: 'text' as 'json' });
}


deleteJob(jobId: number): Observable<any> {
  return this.http.delete<any>(`${this.apiAdminUrl}/jobpostings/delete/${jobId}`, { responseType: 'text' as 'json' });
}



//Admin users control
 // Get all users
 getUsers(): Observable<any[]> {
  return this.http.get<any[]>(`${this.apiAdminUrl}/users/getAllUsers`);
}

// Get user by ID
getUserById(userId: number): Observable<any> {
  return this.http.get<any>(`${this.apiAdminUrl}/getUser/${userId}`);
}

approveUser(userId: number): Observable<any> {
  return this.http.put(`${this.apiAdminUrl}/users/approve/${userId}`, {}, { responseType: 'text' });
}

// Deactivate user (based on user_id)
deactivateUser(userId: number): Observable<string> {
  return this.http.put(`${this.apiAdminUrl}/users/deactivate/${userId}`, {}, { responseType: 'text' });
}




// Update user details
updateUser(userId: number, user: any): Observable<any> {
  return this.http.put(`${this.apiAdminUrl}/users/update/${userId}`, user);
}

// Get users by status
getUsersByStatus(status: string): Observable<any[]> {
  return this.http.get<any[]>(`${this.apiAdminUrl}/status/${status}`);
}

//Insights 
getJobInsights(): Observable<any[]> {
  return this.http.get<any[]>(this.apiAdminUrl+"/insights/userinsights");
}

getJobTrends(): Observable<any[]> {
  return this.http.get<any[]>(this.apiAdminUrl+"/insights/jobstrends");
}


//employer job serive 
getAllJobs():Observable<any>{
  let strUrlGetJobs = this.apiEmployerUrl + "/jobs";
  return this.http.get<any>(strUrlGetJobs);
}
insertJob(jobs : job):Observable<any>{
  let strPostJobsURL = this.apiEmployerUrl+"addJob";
  console.log(("before insert:"+JSON.stringify(job)))

  return this.http.post(strPostJobsURL,job);
}
updateJob(jobId: number, jobRecord: any): Observable<any> {
  return this.http.put(`${this.apiEmployerUrl}/updateJob/${jobId}`, jobRecord, {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  });
}





deleteJobRecord(jobId:number) : Observable<string>{
  let strDeleteUrl = this.apiEmployerUrl+"/deleteJob/"+jobId;
  alert ("job ID:"+jobId);
  return this.http.delete<string> (strDeleteUrl, {responseType:'text' as 'json'}) ;
}

}




