export class job{
    // jobId: number;
    jobName: string;
    department: string;
    skills: string;
    experience: number;
    jobDescription: string;
    salary: number;
    // postDate: string;
    employerId: number;
    companyName: string;  // Add jobCompany
  
    constructor( jobname: string, department: string, skills: string, experience: number,
                jobDescription: string, salary: number,  employerId: number, companyName: string) {
    //   this.jobId = jobid;
      this.jobName = jobname;
      this.department = department;
      this.skills = skills;
      this.experience = experience;
      this.jobDescription = jobDescription;
      this.salary = salary;
    //   this.postDate = postDate;
      this.employerId = employerId;
      this.companyName = companyName;
}
}