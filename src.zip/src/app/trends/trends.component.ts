import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-trends',
  standalone: false,
  templateUrl: './trends.component.html',
  styleUrl: './trends.component.css'
})
export class TrendsComponent {
  @Input() jobTrends: any[] = [];  
  @Output() fetchTrends = new EventEmitter<void>();  


  onFetchTrends(): void {
    this.fetchTrends.emit();  
  }
}
